from flask import Flask, render_template, request,redirect, url_for
import sqlite3
from datetime import datetime

app = Flask(__name__)
def get_db_connection():
    conn = sqlite3.connect('pawan.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/trains_for_passenger', methods=['GET', 'POST'])
def trains_for_passenger():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Booked WHERE Passanger_ssn IN (SELECT ssn FROM Passenger WHERE first_name=? AND last_name=?)", (first_name, last_name))
        
        data = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return render_template('trains_for_passenger.html', passenger_name=f"{first_name} {last_name}", data=data)
    return render_template('trains_for_passenger.html', passenger_name=None, data=None)

@app.route('/passengers_on_date', methods=['GET', 'POST'])
def passengers_on_date():
    if request.method == 'POST':
        TrainDate = request.form['TrainDate']
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT *
            FROM Passenger
            INNER JOIN Booked ON Passenger.SSN = Booked.Passanger_ssn
            INNER JOIN Train ON Booked.Train_Number = Train.Train_Number
            INNER JOIN Train_Status ON Train.TrainName = Train_Status.TrainName
            WHERE Train_Status.TrainDate = ? AND Booked.Status = 'Booked'
            """, (TrainDate,))
        data = cursor.fetchall()
        #conn.commit()
        cursor.close()
        conn.close()
        
        return render_template('passengers_on_date.html', date=f"{TrainDate}", data=data)
    
    return render_template('passengers_on_date.html',date=None,data=None)

@app.route('/passengers_by_age', methods=['GET', 'POST'])
def passengers_by_age():
    if request.method == 'POST':
        age = int(request.form['age'])
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""SELECT Train.Train_Number, Train.TrainName, Train.Source_Station, Train.Destination_Station, Passenger.first_name, Passenger.last_name, Passenger.address, Booked.Ticket_Type, Booked.Status 
                FROM Booked 
                INNER JOIN Passenger ON Booked.Passanger_ssn = Passenger.SSN 
                INNER JOIN Train ON Booked.Train_Number = Train.Train_Number 
                WHERE strftime('%Y', "now") - CAST(substr(Passenger.bdate,7,4) as INTEGER) BETWEEN ? AND ? ORDER BY Train.Train_Number""", (age,age))
        
        data = cursor.fetchall()
        #conn.commit()
        cursor.close()
        conn.close()
        
        return render_template('passengers_by_age.html',data=data)
    
    return render_template('passengers_by_age.html',data=None)

@app.route('/train_passenger_count', methods=['GET', 'POST'])
def train_passenger_count():
    if request.method == 'POST':
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT Train.TrainName, COUNT(Booked.Train_Number) as count FROM Train LEFT JOIN Booked ON Booked.Train_Number=Train.Train_Number WHERE Status='Booked' GROUP BY TrainName")
        data = cursor.fetchall()
        #conn.commit()
        cursor.close()
        conn.close()
        return render_template('train_passenger_count.html', data=data)
    return render_template('train_passenger_count.html', data=None)

@app.route('/passengers_on_train', methods=['GET', 'POST'])
def passengers_on_train():
    if request.method == 'POST':
        train_name = request.form['train_name']
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Booked b INNER JOIN Passenger p ON b.Passanger_ssn=p.SSN WHERE Train_Number=(SELECT Train_Number FROM Train WHERE TrainName=?) AND Status='Booked'", (train_name,))
        data = cursor.fetchall()
        #conn.commit()
        cursor.close()
        conn.close()
        
        return render_template('passengers_on_train.html',train_name=train_name,data=data)
    
    return render_template('passengers_on_train.html',train_name=None,data=None)


@app.route('/cancel_ticket', methods=['GET', 'POST'])
def cancel_ticket():
    if request.method == 'POST':
        passenger_ssn = request.form['passenger_ssn']
        train_number = request.form['train_number']
        ticket_type = request.form['ticket_type']
        conn = get_db_connection()
        cursor = conn.cursor()
        # check if the passenger has a confirmed ticket for the given train and ticket type
        query = f"SELECT * FROM Booked WHERE Passanger_ssn = '{passenger_ssn}' AND Train_Number = '{train_number}' AND Ticket_Type = '{ticket_type}' AND Status = 'Booked'"
        cursor.execute(query)
        booking = cursor.fetchone()
        if booking:
            # delete the booking record and update the status of the waiting list passengers
            query = f"DELETE FROM Booked WHERE Passanger_ssn = '{passenger_ssn}' AND Train_Number = '{train_number}' AND Ticket_Type = '{ticket_type}'"
            cursor.execute(query)
            if ticket_type == 'Premium':
                query = f"UPDATE Booked SET Status = 'Booked' WHERE Train_Number = '{train_number}' AND Ticket_Type = 'Premium' AND Status = 'WaitL' AND Passanger_ssn IN (SELECT Passanger_ssn FROM Booked WHERE Train_Number = '{train_number}' AND Ticket_Type = 'Premium' AND Status = 'WaitL' ORDER BY Train_Number LIMIT 1)"
            else:
                query = f"UPDATE Booked SET Status = 'Booked' WHERE Train_Number = '{train_number}' AND Ticket_Type = 'General' AND Status = 'WaitL' AND Passanger_ssn IN (SELECT Passanger_ssn FROM Booked WHERE Train_Number = '{train_number}' AND Ticket_Type = 'General' AND Status = 'WaitL' ORDER BY Train_Number LIMIT 1)"
            cursor.execute(query)
            conn.commit()
            message = 'Ticket cancelled successfully'
        else:
            message = 'No confirmed booking found for the given passenger, train, and ticket type'
        cursor.close()
        conn.close()
        return render_template('cancel_ticket.html', message=message)
    else:
        return render_template('cancel_ticket.html')

if __name__ == '__main__':
    app.run(debug=False)